package game.dori.service;

public interface CartService {

}
