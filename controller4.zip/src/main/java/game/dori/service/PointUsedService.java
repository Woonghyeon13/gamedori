package game.dori.service;

public interface PointUsedService {

}
