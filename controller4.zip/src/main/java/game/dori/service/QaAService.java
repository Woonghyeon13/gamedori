package game.dori.service;

public interface QaAService {

}
