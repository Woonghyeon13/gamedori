package game.dori.service;

public interface UsepointService {

}
