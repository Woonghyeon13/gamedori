package game.dori.service;

public interface NoticeService {

}
