package game.dori.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import game.dori.dao.MemberDAO;
import game.dori.vo.MEMBER_VO;

@Service
public class MemberServiceImpl implements MemberService {

	@Autowired
	private MemberDAO memberDAO;
	
	MEMBER_VO memverVO;
	
	@Autowired
	JavaMailSender mailSender;
	


	@Override
	public MEMBER_VO selectByBno(int member_idx) {
		// TODO Auto-generated method stub
		return memberDAO.selectByBno(member_idx);
	}

	@Override
	public MEMBER_VO selectByEmail(String id) {
		// TODO Auto-generated method stub
		return memberDAO.selectByEmail(id);
	}

	@Override
	public int insert(MEMBER_VO memberVO) {
		// TODO Auto-generated method stub
		return memberDAO.insert(memberVO);
	}

	@Override
	public void update(MEMBER_VO memberVO) {
	    memberDAO.update(memberVO);
	}

	@Override
	public int insertMember(MEMBER_VO memberVO) {
		// TODO Auto-generated method stub
		return memberDAO.insertMember(memberVO);
	}

	

	
	
}
